package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Emerald & Gold Luxury Financial Palette
val EmeraldPrimary = Color(0xFF059669)
val EmeraldLight = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val EmeraldContainer = Color(0xFFD1FAE5)
val OnEmeraldContainer = Color(0xFF064E3B)

val GoldAccent = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFBBF24)
val GoldContainer = Color(0xFFFEF3C7)
val OnGoldContainer = Color(0xFF78350F)

val DeepNavy = Color(0xFF0F172A)
val SlateBackground = Color(0xFFF8FAFC)
val SlateCard = Color(0xFFFFFFFF)
val SlateBorder = Color(0xFFE2E8F0)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)

// Dark Theme Colors - Lively Midnight Navy & High Contrast
val DarkBackground = Color(0xFF0E1626) // Modern rich navy instead of pitch black
val DarkSurface = Color(0xFF1B273D)    // Cheerful, luminous slate container
val DarkCard = Color(0xFF1F2D47)       // Elevated vibrant card surface
val DarkBorder = Color(0xFF384F73)     // Visible, crisp border
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFFCBD5E1) // High-contrast, easily readable secondary text
val DarkPrimary = Color(0xFF10B981)    // Vivid emerald
val DarkPrimaryContainer = Color(0xFF065F46)
