package com.example.data.model

data class MarketRateItem(
    val key: String,
    val title: String,
    val priceTomans: Long,
    val changePercent: Double,
    val changeTomans: Long = 0L,
    val isPositiveChange: Boolean,
    val timeFormatted: String,
    val unitLabel: String = "تومان",
    val displayPriceFormatted: String? = null,
    val displayDiffFormatted: String? = null
)

data class MarketRatesState(
    val dollar: MarketRateItem = MarketRateItem(
        key = "dollar",
        title = "دلار",
        priceTomans = 69200L,
        changePercent = 0.45,
        changeTomans = 350L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز"
    ),
    val euro: MarketRateItem = MarketRateItem(
        key = "euro",
        title = "یورو",
        priceTomans = 75300L,
        changePercent = 0.32,
        changeTomans = 240L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز"
    ),
    val sekehEmami: MarketRateItem = MarketRateItem(
        key = "sekee",
        title = "سکه امامی",
        priceTomans = 54800000L,
        changePercent = 0.65,
        changeTomans = 350000L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز"
    ),
    val robSekeh: MarketRateItem = MarketRateItem(
        key = "rob",
        title = "ربع سکه",
        priceTomans = 18900000L,
        changePercent = 0.53,
        changeTomans = 100000L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز"
    ),
    val goldOunce: MarketRateItem = MarketRateItem(
        key = "ons",
        title = "انس جهانی طلا",
        priceTomans = 2745L,
        changePercent = 0.90,
        changeTomans = 36L,
        isPositiveChange = false,
        timeFormatted = "به‌روزرسانی روز",
        unitLabel = "دلار",
        displayPriceFormatted = "$۲,۷۴۵",
        displayDiffFormatted = "$۳۶"
    ),
    val gold18k: MarketRateItem = MarketRateItem(
        key = "geram18",
        title = "طلای ۱۸ عیار",
        priceTomans = 4650000L,
        changePercent = 0.48,
        changeTomans = 22000L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز"
    ),
    val bitcoin: MarketRateItem = MarketRateItem(
        key = "crypto-bitcoin",
        title = "بیت‌کوین",
        priceTomans = 76034L,
        changePercent = 0.34,
        changeTomans = 258L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز",
        unitLabel = "دلار",
        displayPriceFormatted = "$۷۶,۰۳۴",
        displayDiffFormatted = "$۲۵۸"
    ),
    val crudeOil: MarketRateItem = MarketRateItem(
        key = "oil_brent",
        title = "نفت برنت",
        priceTomans = 75L,
        changePercent = 0.42,
        changeTomans = 1L,
        isPositiveChange = true,
        timeFormatted = "به‌روزرسانی روز",
        unitLabel = "دلار",
        displayPriceFormatted = "$۷۴.۸",
        displayDiffFormatted = "$۰.۸"
    ),
    val lastUpdateTime: String = "لحظه‌ای (TGJU)",
    val isLoading: Boolean = false,
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)
