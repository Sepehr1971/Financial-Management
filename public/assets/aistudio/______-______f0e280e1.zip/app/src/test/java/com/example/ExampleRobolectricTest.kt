package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.utils.PersianDateHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("مدیریت هزینه", appName)
  }

  @Test
  fun `persian calendar conversion test`() {
    // 2026-10-09 is 17 Mehr 1405
    val shamsi = PersianDateHelper.gregorianToJalali(2026, 10, 9)
    assertEquals(1405, shamsi.year)
    assertEquals(7, shamsi.month)
    assertEquals(17, shamsi.day)
    assertEquals("مهر", shamsi.monthName)
  }

  @Test
  fun `folder matcher isolates categories and prevents cross contamination`() {
    val matcher = com.example.data.repository.FolderMatcher

    // 1. "بنزین و حمل و نقل" must NOT match "خرید تنقلات" (which has 'نقل' substring)
    val transportMatchesSnacks = matcher.matches(
      expenseEffectiveFolder = "خرید تنقلات",
      expenseCustomFolder = null,
      expenseTitle = "خرید تنقلات",
      isAnnualExpense = false,
      folderFilter = "بنزین و حمل و نقل"
    )
    org.junit.Assert.assertFalse("Gasoline/Transport must not match snacks", transportMatchesSnacks)

    // 2. "پوشاک" must NOT match "خرید میوه", "خرید سوپرمارکت", "خرید مرغ", or "خرید تنقلات"
    val clothingMatchesFruit = matcher.matches("خرید میوه", null, "خرید میوه", false, "پوشاک")
    val clothingMatchesSupermarket = matcher.matches("خرید سوپرمارکت", null, "خرید سوپرمارکت", false, "پوشاک")
    val clothingMatchesChicken = matcher.matches("خرید مرغ", null, "خرید مرغ", false, "پوشاک")
    val clothingMatchesSnacks = matcher.matches("خرید تنقلات", null, "خرید تنقلات", false, "پوشاک")
    org.junit.Assert.assertFalse(clothingMatchesFruit)
    org.junit.Assert.assertFalse(clothingMatchesSupermarket)
    org.junit.Assert.assertFalse(clothingMatchesChicken)
    org.junit.Assert.assertFalse(clothingMatchesSnacks)

    // 3. "خرید میوه" must NOT match "خرید مرغ"
    val fruitMatchesChicken = matcher.matches("خرید مرغ", null, "خرید مرغ", false, "خرید میوه")
    org.junit.Assert.assertFalse(fruitMatchesChicken)

    // 4. "خرید مرغ" must NOT match "خرید سوپرمارکت"
    val chickenMatchesSupermarket = matcher.matches("خرید سوپرمارکت", null, "خرید سوپرمارکت", false, "خرید مرغ")
    org.junit.Assert.assertFalse(chickenMatchesSupermarket)

    // 5. "خرید تنقلات" must NOT match "خرید مرغ"
    val snacksMatchesChicken = matcher.matches("خرید مرغ", null, "خرید مرغ", false, "خرید تنقلات")
    org.junit.Assert.assertFalse(snacksMatchesChicken)

    // 6. "هزینه‌های نگهداری ماشین" must NOT match annual insurance ("بیمه تکمیلی" or "بیمه موتور")
    val carMatchesTakmili = matcher.matches("سهم هزینه‌های سالانه (ماهانه)", "هزینه‌های سالانه و تعهدات", "بیمه تکمیلی درمان", true, "هزینه‌های نگهداری ماشین")
    val carMatchesMotorIns = matcher.matches("سهم هزینه‌های سالانه (ماهانه)", "هزینه‌های سالانه و تعهدات", "بیمه موتورسیکلت", true, "هزینه‌های نگهداری ماشین")
    org.junit.Assert.assertFalse(carMatchesTakmili)
    org.junit.Assert.assertFalse(carMatchesMotorIns)

    // 7. Per user request: Motorcycle monthly expenses and annual motorcycle insurance unify under "موتور"
    val motorMatchesMotorIns = matcher.matches("سهم هزینه‌های سالانه (ماهانه)", "هزینه‌های سالانه و تعهدات", "بیمه موتور", true, "موتور")
    org.junit.Assert.assertTrue(motorMatchesMotorIns)

    // 8. "هزینه‌های نگهداری ماشین" and "هزینه نگهداری ماشین" map to identical canonical group ID
    val carPluralGroup = matcher.getCanonicalGroupId("هزینه‌های نگهداری ماشین")
    val carSingularGroup = matcher.getCanonicalGroupId("هزینه نگهداری ماشین")
    assertEquals(carPluralGroup, carSingularGroup)

    // 9. "سوپرمارکت و خوراکی" and "سوپر مارکت و خوراکی" map to identical group
    val superNoSpace = matcher.getCanonicalGroupId("سوپرمارکت و خوراکی")
    val superWithSpace = matcher.getCanonicalGroupId("سوپر مارکت و خوراکی")
    assertEquals(superNoSpace, superWithSpace)
  }
}
